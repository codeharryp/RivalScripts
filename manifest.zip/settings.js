const Install_Urls = [
    "index.html",
    "https://rivalscripts.com/"
]

const Uninstall_Url = "https://rivalscripts.com/";